package models;

import com.google.android.gms.maps.model.LatLng;

interface ClusterItem {
    LatLng getPosition();

    String getTitle();

    String getSnippet();
}
