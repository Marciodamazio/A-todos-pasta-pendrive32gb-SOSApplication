package com.example.sosapplication;

public interface IProfile {

    void onImageSelected(int resource);
}
